import pprint
import random

def creadicc():
    diccionario = {"nombre": "PEDRO GOKU", "edad": 19, "sexo": "HOMBRE", "ciudad": "ENSENADA"}
    pprint.pprint(diccionario, indent=4, sort_dicts=False)

def registro():
    valores=[];
    
    nombre_h=["Juan","Luis", "Carlos","Roberto","Pedro","Abraham","Tulio"]
    nombre_m=["Sandra","Lupita","Maria","Sonia","Ana","Vanessa","Cristina"]
    apellidos=["Villalobos","Sanchez","Perez","Casas","Paredes","Canales","Huerta","Gutierrez","Herrera","Chavez","Cota"]
    
    puesto=["Supervisor","Encargad@","Conserje","Gerente","Guardia","Empleado Gral","Jefe"]
    sexo=["HOMBRE","MUJER"]
    
    valores.append(random.randint(10, 500))
    valores.append(random.choice(apellidos))
    valores.append(random.choice(apellidos))
    sex=random.randint(0, 1)
    if sex == 0 :
        valores.append(random.choice(nombre_h))
    else:
        valores.append(random.choice(nombre_m))
        
    valores.append(random.choice(puesto))
    valores.append(sexo[sex])
    return valores