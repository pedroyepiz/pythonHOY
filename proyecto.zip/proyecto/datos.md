|   Id | Ap.Paterno   | Ap.Materno   | Nombre   | Puesto     | Sexo   |
|-----:|:-------------|:-------------|:---------|:-----------|:-------|
|  452 | Paredes      | Chavez       | Luis     | Encargad@  | HOMBRE |
|  233 | Paredes      | Chavez       | Pedro    | Gerente    | HOMBRE |
|  339 | Cota         | Herrera      | Pedro    | Gerente    | HOMBRE |
|   56 | Herrera      | Cota         | Roberto  | Supervisor | HOMBRE |
|   36 | Gutierrez    | Huerta       | Abraham  | Guardia    | HOMBRE |
|   27 | Paredes      | Villalobos   | Abraham  | Supervisor | HOMBRE |
|  371 | Perez        | Sanchez      | Maria    | Jefe       | MUJER  |
|  373 | Paredes      | Paredes      | Roberto  | Encargad@  | HOMBRE |
|  436 | Casas        | Chavez       | Carlos   | Gerente    | HOMBRE |
|   54 | Villalobos   | Huerta       | Juan     | Encargad@  | HOMBRE |
|  350 | Herrera      | Perez        | Lupita   | Supervisor | MUJER  |
|  157 | Gutierrez    | Gutierrez    | Pedro    | Conserje   | HOMBRE |
|  438 | Casas        | Herrera      | Luis     | Encargad@  | HOMBRE |
|  328 | Gutierrez    | Villalobos   | Sonia    | Conserje   | MUJER  |
|  172 | Cota         | Cota         | Juan     | Guardia    | HOMBRE |